import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.HttpClientUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class crawler {
    //爬取搜狗问问页面的问答连接
    private static ArrayList<String> hrefList=new ArrayList();
    private static ArrayList<ArrayList<String>>questionAndAnswer=new ArrayList<>();
    public static ArrayList<ArrayList<String>> getQuestionAndAnswer() {
        return questionAndAnswer;
    }
    public static void getHref(int page){
        CloseableHttpClient httpClient=HttpClients.createDefault();
        CloseableHttpResponse response=null;
        //悟空问答，搜索新冠肺炎url
        HttpGet request=new HttpGet //模拟浏览器请求头
                ("https://www.sogou.com/sogou?query=%E6%96%B0%E5%86%A0%E8%82%BA%E7%82%8E&insite=wenwen.sogou.com&pid=sogou-wsse-a9e18cb5dd9d3ab4&rcer=&page="+page+"&ie=utf8");

        request.setHeader("User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36");
        try{
            response=httpClient.execute(request);
            if(response.getStatusLine().getStatusCode()==HttpStatus.SC_OK){
                HttpEntity httpEntity = response.getEntity();
                String html = EntityUtils.toString(httpEntity, "utf-8");
                //System.out.println(html);
                Document document=Jsoup.parse(html);
                Elements postItems=document.getElementsByClass("vr-title");
               // Elements postItems=document.getElementsByClass("fb");
                                          //问题出在这里，通过“fb”无法获得匹配的postItems，要查看源代码改变检索词
                for(Element postItem:postItems){
                    Elements link=postItem.select("a");
                    //System.out.println(link.attr("href"));
                    hrefList.add(link.attr("href"));
                }
            }else {
                System.out.println("返回状态错误");//"返回状态不是200"
                System.out.println(EntityUtils.toString(response.getEntity(), "utf-8"));
            }
        }catch (ClientProtocolException e){System.out.print("客户端协议异常："+e);}
        catch (IOException e){System.out.print("IO异常："+e);}
        finally {
            HttpClientUtils.closeQuietly(response);
            HttpClientUtils.closeQuietly(httpClient);
        }
    }

    public static String GetNewHerf(String url) {//还需要再跳转一层才能获得问答详情页的html
        String temp="";
        CloseableHttpClient httpClient= HttpClients.createDefault();
        CloseableHttpResponse response=null;

        url=new String("https://www.sogou.com"+url);//发现直接使用url无法跳转至问答详情页面，需要
        HttpGet request=new HttpGet(url);
        request.setHeader("User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36");

//        request.setHeader("User-Agent",
//                "Mozilla/5.0 (Windows NT 6.1; rv:6.0.2) Gecko/20100101 Firefox/6.0.2");
        try{
            response=httpClient.execute(request);
            if(response.getStatusLine().getStatusCode()== HttpStatus.SC_OK){
                HttpEntity httpEntity = response.getEntity();
                String html = EntityUtils.toString(httpEntity, "utf-8");
                Document document=Jsoup.parse(html);
                Element element = document.select("script").first();

                temp=element.toString();
                Pattern p=Pattern.compile("\"(.*?)\"");
                Matcher m=p.matcher(temp);
                while(m.find()) {
                    temp=temp.replace(temp,m.group());
                }
                temp=temp.replace("\"","");
                //System.out.println(temp);

            }else {
                System.out.println("返回状态不是200");
                System.out.println(EntityUtils.toString(response.getEntity(), "utf-8"));
            }
        }catch (ClientProtocolException e){System.out.print("客户端协议异常："+e);}
        catch (IOException e){System.out.print("IO异常："+e);}
        finally {
            HttpClientUtils.closeQuietly(response);
            HttpClientUtils.closeQuietly(httpClient);
        }
        return temp;
    }

    //返回一个数组，第一个元素为问题，第二个元素为答案
    public static ArrayList<String> getQuestionAndAnswer(String url){

        ArrayList<String>temp=new ArrayList<>();
        CloseableHttpClient httpClient= HttpClients.createDefault();
        CloseableHttpResponse response=null;
        //搜狗问问，搜索新冠肺炎url
        HttpGet request=new HttpGet(url);
        request.setHeader("User-Agent","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.82 Safari/537.36");
        try{
            response=httpClient.execute(request);
            if(response.getStatusLine().getStatusCode()== HttpStatus.SC_OK){
                HttpEntity httpEntity = response.getEntity();

                byte[] bytes = EntityUtils.toByteArray(httpEntity);
                String html = new String(bytes, "utf-8");//使用字节流能大幅度提升转换速度
                //String html = EntityUtils.toString(httpEntity, "utf-8");
                //System.out.println(html);
               
                Document document= Jsoup.parse(html);
                Element title=document.getElementById("question_title_val");//获得问题标题
                //Element title=document.getElementById("question_title");
                //System.out.print(title.text());
                temp.add(title.text().replaceAll("[^\\u4E00-\\u9FA5]",""));

                Elements preTag=document.getElementsByTag("pre");//获得回答文本
                //System.out.print(preTag.get(0).text());
                temp.add(preTag.get(0).text().replaceAll("[\\u25c6~\\u25c7]|[\\——]|[\\▲]|[\\△]]",""));
            }else {
                System.out.println("返回状态不是200");
                System.out.println(EntityUtils.toString(response.getEntity(), "utf-8"));
            }
        }catch (ClientProtocolException e){System.out.print("客户端协议异常："+e);}
        catch (IOException e){System.out.print("IO异常："+e);}
        finally {
            HttpClientUtils.closeQuietly(response);
            HttpClientUtils.closeQuietly(httpClient);
        }
        return temp;
    }
    //爬取第maxPage页的问题与答案
    public static void spiderQuestionAndAnswer(int maxPage)throws Exception{
        //现场休眠1000毫秒（作用是使当前线程暂时睡眠指定的时间）
        Thread.sleep(1000);
        getHref(maxPage);

//        String href=hrefList.get(4);
//        String newhref=GetNewHerf(href);
//        ArrayList<String> ss=getQuestionAndAnswer(newhref);
//        questionAndAnswer.add(ss);

        for(String href:hrefList){
            //现场休眠1000毫秒（作用是使当前线程暂时睡眠指定的时间）
            Thread.sleep(1000);
            String newhref=GetNewHerf(href);

            questionAndAnswer.add(getQuestionAndAnswer(newhref));
        }

    }
    public static void main(String[] args) throws Exception{
        System.getProperties().setProperty("http.proxyHost", "112.105.11.196");
        System.getProperties().setProperty("http.proxyPort", "8088");
        int maxPage=19;//1~20
        //现场休眠1000毫秒（作用是使当前线程暂时睡眠指定的时间）
        Thread.sleep(1000);
        spiderQuestionAndAnswer(maxPage);

        File f = new File("19.txt");//1~20.txt
        FileOutputStream fop = new FileOutputStream(f);
        OutputStreamWriter writer = new OutputStreamWriter(fop, "UTF-8");
        // 构建OutputStreamWriter对象,参数可以指定编码,默认为操作系统默认编码,windows上是gbk
        for(ArrayList<String>temp:questionAndAnswer){
            for(String qa:temp){
                System.out.println(qa);
                writer.append(qa);
            }
            System.out.println();
            writer.append("\n");
        }
        //正则表达式字符处理测试
        /*String temp="为阴性达到出院标准】,,,,▲◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇——————————";
        System.out.print(temp.replaceAll("[^\\u4E00-\\u9FA5]",""));*/
        writer.close();
        // 关闭写入流,同时会把缓冲区内容写入文件,所以上面的注释掉
        fop.close();
    }


}
