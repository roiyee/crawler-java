package cn.yry.jd.task;

import cn.yry.jd.pojo.Item;
import cn.yry.jd.service.ItemService;
import cn.yry.jd.util.HttpUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;


@Component
public class item_task {

    @Autowired
    private HttpUtils httpUtils;

    @Autowired
    private ItemService itemService;

    private static final ObjectMapper MAPPER = new ObjectMapper();

    // 当下载任务完成后, 间隔多长时间进行下一次的任务.
    @Scheduled(fixedDelay = 100 * 1000)
    public void itemTask() throws Exception {
        // 声明需要解析的初始地址
        String url = "https://search.jd.com/Search?keyword=%E6%89%8B%E6%9C%BA&enc=utf-8" +
                "&pvid=f112521d94c04007826aa41adcbb0658&page=";
        // 按照页面对手机的搜索结果进行遍历解析(京东手机界面点下一页页码数＋2，因此只有1 3 5等奇数页码)
        //for (int i = 1; i < 10; i = i + 2) {//只有1、3、5、7、9页，最多5页
        for (int i = 1; i < 2; i = i + 2) {//数据太多，改为只抽第一页
            String html = httpUtils.doGetHtml(url + i);
            //  解析页面, 获取商品数据并存储
            this.parse(html);
        }

        System.out.println("手机数据抓取完成!");
    }

    // 解析页面, 获取商品数据并存储
    private void parse(String html) throws Exception {
        // 解析html获取Document对象
        Document doc = Jsoup.parse(html);
        // 获取spu信息
        Elements spuEles = doc.select("div#J_goodsList > ul > li");

        for (Element spuEle : spuEles) {//由页面代码得，应先拿到大图商品的SPU，再获取其中预览图的sku(见注解图1)
            // 排除没有data-spu的值的广告
            if (StringUtils.isNotEmpty(spuEle.attr("data-spu"))) {
                // 获取spu （以下筛选代码来源见注解图2）
                long spu = Long.parseLong(spuEle.attr("data-spu"));//将字符串转为整型
                // 获取sku信息
                Elements skuEles = spuEle.select("li.ps-item");
                for (Element skuEle : skuEles) {
                    // 获取sku
                    long sku = Long.parseLong(skuEle.select("[data-sku]").first().attr("data-sku"));
                    // 根据sku查询商品数据
                    Item item = new Item();
                    item.setSku(sku);
                    List<Item> list = this.itemService.findAll(item);//得到一个商品list
                    if (list.size() > 0) {
                        // 如果商品存在, 就进行下一个循环, 该商品不保存, 因为已存在
                        continue;
                    }
                    // 设置商品的spu (sku前面代码中已经设置)
                    item.setSpu(spu);
                    // 获取商品的详情的url （点进大图得到网址 eg：https://item.jd.com/100016799352.html）
                    String itemUrl = "https://item.jd.com/" + sku + ".html";
                    item.setUrl(itemUrl);
                    // 获取商品的图片
                    //img12.360buyimg.com/n7/jfs/t1/22035/32/16283/167144/627664dcE8977ba7a/fd9c1b9595cc9f02.jpg
                    //String picUrl = skuEle.select("img[data-sku]").first().attr("src");
                    // (先在这一部调试一次，会在参数栏观察到网址在“data-lazy-img”后而不是“src"后)
                    String picUrl = "https:" + skuEle.select("img[data-sku]").first().attr("data-lazy-img");
                                                      //找到sku，再从中找到图片链接，见注解图3
                    picUrl = picUrl.replace("/n7/", "/n0/" );//n7换成n0图片会变大
                    String picName = this.httpUtils.doGetImage(picUrl);
                    item.setPic(picName);
                    // 获取商品的价格 (见注解4)
                    String priceJson = this.httpUtils.doGetHtml("https://p.3.cn/prices/mgets?skuIds=J_" + sku);
                                              //初次获取到的商品价格信息仍然需要进行解析 使用工具类MAPPER  https://p.3.cn/prices/mgets?skuIds=J_100016799352
                    double price = MAPPER.readTree(priceJson).get(0).get("p").asDouble();//把字符串转成double
                    item.setPrice(price);
                    // 获取商品的标题
                    String itemInfo = this.httpUtils.doGetHtml(item.getUrl());//对商品信息进行解析得到标题
                    String title = Jsoup.parse(itemInfo).select("div.sku-name").text();//获取方式见注解5
                    item.setTitle(title);
                    //item.setTitle();
                    //获取商品当前时间
                    item.setCreated(new Date());
                    //获取更新时间（商品创建时间）
                    item.setUpdated(item.getCreated());

                    // 保存商品数据到数据库中
                    this.itemService.save(item);
                }
            }

        }
    }
}
