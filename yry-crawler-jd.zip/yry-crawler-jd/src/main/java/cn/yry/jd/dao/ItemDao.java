package cn.yry.jd.dao;

import cn.yry.jd.pojo.Item;
import org.springframework.data.jpa.repository.JpaRepository;
// Item的Dao接口
public interface ItemDao extends JpaRepository<Item, Long> {//Item主键是long型

}
